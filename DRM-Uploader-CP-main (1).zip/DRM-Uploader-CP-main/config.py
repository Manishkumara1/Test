#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (c) ACE 

import os

class Config(object):
    # get a token from @BotFather
    pass
    """
    BOT_TOKEN = os.environ.get("BOT_TOKEN", "7103819451:AAFp02pmf0FQjtcaP1phUTm4YPFGwt0IzwY")
    API_ID = int(os.environ["API_ID", 20346550]
    API_HASH = os.environ["API_HASH", "bc79c3bea7a626887bdc0871eecf0327"]
    AUTH_USERS = "7081036509"""
 
